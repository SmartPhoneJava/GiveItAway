self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3d75b21373858f4a97fe55052032c3ab",
    "url": "./index.html"
  },
  {
    "revision": "ee2043390d9fcc03ef9e",
    "url": "./static/css/2.733ba2d0.chunk.css"
  },
  {
    "revision": "d7a57e77b7df0ea8e1f9",
    "url": "./static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "ee2043390d9fcc03ef9e",
    "url": "./static/js/2.bf9b0d6d.chunk.js"
  },
  {
    "revision": "5a768c182a70240d1505314e62be011b",
    "url": "./static/js/2.bf9b0d6d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d7a57e77b7df0ea8e1f9",
    "url": "./static/js/main.f4cec535.chunk.js"
  },
  {
    "revision": "77af7603f34dd3c911fe",
    "url": "./static/js/runtime-main.47291857.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "./static/media/persik.4e1ec840.png"
  }
]);