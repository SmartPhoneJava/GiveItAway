self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8a58275c0175388a6f5ab38c7564b3d3",
    "url": "./index.html"
  },
  {
    "revision": "f442ba7842fcfe229893",
    "url": "./static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "9c57fb91749ad1796bb6",
    "url": "./static/css/main.ddb59030.chunk.css"
  },
  {
    "revision": "f442ba7842fcfe229893",
    "url": "./static/js/2.0b98d234.chunk.js"
  },
  {
    "revision": "7af051629a180b3886b7a3b734d60d8c",
    "url": "./static/js/2.0b98d234.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9c57fb91749ad1796bb6",
    "url": "./static/js/main.e35b09e3.chunk.js"
  },
  {
    "revision": "14bc37f40d0dd73adb92",
    "url": "./static/js/runtime-main.355e1e95.js"
  },
  {
    "revision": "077388f38526f454d507e549eddde82c",
    "url": "./static/media/animal.077388f3.png"
  },
  {
    "revision": "60cb8ad7bb020e6a3f1830e294ca48b0",
    "url": "./static/media/another.60cb8ad7.png"
  },
  {
    "revision": "baa397fca27cde97566a26d17a71171e",
    "url": "./static/media/book.baa397fc.png"
  },
  {
    "revision": "c670dc247939f191495a59bd79dd8e48",
    "url": "./static/media/build.c670dc24.png"
  },
  {
    "revision": "aace577d07639cf19ead776ae07b7e0e",
    "url": "./static/media/child.aace577d.png"
  },
  {
    "revision": "b191539b854d969df8bf80efe68b2ce8",
    "url": "./static/media/clothers.b191539b.png"
  },
  {
    "revision": "c5a1e65766cfd075bae0241c9bca1635",
    "url": "./static/media/cosmetic.c5a1e657.png"
  },
  {
    "revision": "ff8cd7b326974962af4af26307d6bc27",
    "url": "./static/media/electronics.ff8cd7b3.png"
  },
  {
    "revision": "1e7f5d3e7130b6c0d38ae2fcf34b85d8",
    "url": "./static/media/flora.1e7f5d3e.png"
  },
  {
    "revision": "5224437e4680128dc658d97a35d6a281",
    "url": "./static/media/food.5224437e.png"
  },
  {
    "revision": "e382b4dcfb490bd5a69a21754208f37f",
    "url": "./static/media/furniture.e382b4dc.png"
  },
  {
    "revision": "5a7e63cf0b47c002929cd3edb03fae82",
    "url": "./static/media/music.5a7e63cf.png"
  },
  {
    "revision": "e9a9fe8e37c5c146273889ee29fa9298",
    "url": "./static/media/old.e9a9fe8e.png"
  },
  {
    "revision": "890ef12de627159070a16624940d3d22",
    "url": "./static/media/pencil.890ef12d.png"
  },
  {
    "revision": "fdd3661404f3c6dc1dd7c51c3aa8fd3a",
    "url": "./static/media/play.fdd36614.png"
  },
  {
    "revision": "7eacba6b216ed6f5d9130a41896af469",
    "url": "./static/media/question.7eacba6b.png"
  },
  {
    "revision": "51336e9ea417fed3de655ac22a0fdf5b",
    "url": "./static/media/sport.51336e9e.png"
  }
]);